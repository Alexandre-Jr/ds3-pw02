#ifndef FUNC1_H
#define FUNC1_H

//Bibliotecas padrões
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Arquivos header
#include "../dados.h"
#include "./utils.h"

//Função de leitura de registro por um arquivo .csv e gravação em um arquivo .bin
void func1();

#endif //FUNC1_H