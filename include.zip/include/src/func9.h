#ifndef FUNC9_H
#define FUNC9_H

// Include bibliotecas padroes do c

#include <stdio.h>
#include <stdlib.h>

// Dependências
#include "../include/src/utils.h"
#include "../include/src/structs/arvoreb.h"

// Funcao principal
void func9();

#endif // FUNC9_H