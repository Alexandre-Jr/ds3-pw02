#ifndef FUNC8_H
#define FUNC8_H

// Include bibliotecas padroes do c

#include <stdio.h>
#include <stdlib.h>

// Dependências
#include "../include/src/utils.h"
#include "../include/src/structs/arvoreb.h"

// Funcao principal
void func8();

#endif // FUNC8_H