#ifndef FUNC2_H
#define FUNC2_H

// Include bibliotecas padroes do c
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Include os tipos de dados
#include "../dados.h"


#include "./utils.h"

// Funcao principal da funcionalidade 2 que printa o valor de cada regsitro
void func2();

#endif

