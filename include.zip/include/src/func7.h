#ifndef FUNC7_H
#define FUNC7_H

// Include bibliotecas padroes do c

#include <stdio.h>
#include <stdlib.h>

// Dependências
#include "../include/src/utils.h"
#include "../include/src/structs/arvoreb.h"

// Funcao principal
void func7();

#endif // FUNC7_H