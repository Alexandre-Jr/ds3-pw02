#ifndef FUNC6_H
#define FUNC6_H

// Include bibliotecas padroes do c

#include <math.h>
#include <string.h>

// Include bibliotecas do projeto

#include "../dados.h"
#include "utils.h"

// Funcao principal da funcionalidade de busca
void func6();

#endif
