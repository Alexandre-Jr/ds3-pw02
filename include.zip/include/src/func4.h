#ifndef FUNC4_H
#define FUNC4_H

// Include bibliotecas padroes do c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Include bibliotecas do projeto

#include "../dados.h"
#include "./utils.h"


// Funcao principal da funcionalidade de remoção
void func4();

#endif //FUNC4_H